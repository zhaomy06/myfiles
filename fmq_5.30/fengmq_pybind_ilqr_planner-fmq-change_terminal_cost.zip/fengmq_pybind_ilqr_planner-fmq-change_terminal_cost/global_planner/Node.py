

class Node():
    def __init__(self):
        pass